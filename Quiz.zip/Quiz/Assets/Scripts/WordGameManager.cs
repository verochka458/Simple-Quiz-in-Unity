using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using System.Collections.Generic;
using TMPro;


public class WordGameManager : MonoBehaviour
{
    public TextMeshProUGUI scrambledWordText;
    public TMP_InputField playerInput;
    public TextMeshProUGUI feedbackText;

    private List<Question> wordQuestions;
    private int currentWordIndex;

    private void Start()
    {
        wordQuestions = GameManager.Instance.level3Questions;
        DisplayWord();
    }

    void DisplayWord()
    {
        if (currentWordIndex >= wordQuestions.Count)
        {
            GameManager.Instance.LoadNextLevel("GameOver");
            return;
        }

        string word = wordQuestions[currentWordIndex].correctWord;
        scrambledWordText.text = new string(word.ToCharArray().OrderBy(c => Random.value).ToArray());
        playerInput.text = "";
        feedbackText.text = "";
    }

    public void SubmitWord()
    {
        string entered = playerInput.text.Trim().ToLower();
        string correct = wordQuestions[currentWordIndex].correctWord.ToLower();

        if (entered == correct)
        {
            feedbackText.text = "Correct!";
            GameManager.Instance.AddScore(1);
            Debug.Log("Current Score: " + GameManager.Instance.currentScore);
        }
        else
        {
            feedbackText.text = "Try again!";
            Debug.Log("Current Score: " + GameManager.Instance.currentScore);
        }

        currentWordIndex++;
        DisplayWord();
    }
}
