using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Question
{
    public string questionText;
    public string[] options; 
    public int correctOptionIndex; 
    public bool isTrueFalse; 
    public string correctWord; 
    public Sprite questionImage; 
}
