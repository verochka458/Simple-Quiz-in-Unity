using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class UIManager : MonoBehaviour
{
    public TextMeshProUGUI questionText;
    public Button[] optionButtons;
    public Image questionImage;

    private List<Question> currentQuestions;
    private int currentQuestionIndex;

    private void Start()
    {
        if (SceneManager.GetActiveScene().name == "QuizLevel1")
            currentQuestions = GameManager.Instance.level1Questions;
        else if (SceneManager.GetActiveScene().name == "QuizLevel2")
            currentQuestions = GameManager.Instance.level2Questions;

        DisplayQuestion();
    }

    public void DisplayQuestion()
    {
        if (currentQuestionIndex >= currentQuestions.Count)
        {
            if (SceneManager.GetActiveScene().name == "QuizLevel1")
                GameManager.Instance.LoadNextLevel("QuizLevel2");
            else if (SceneManager.GetActiveScene().name == "QuizLevel2")
                GameManager.Instance.LoadNextLevel("QuizLevel3");

            return;
        }

        Question q = currentQuestions[currentQuestionIndex];

        questionText.text = q.questionText;
        // questionImage.sprite = q.questionImage;

        if (q.isTrueFalse)
        {
            optionButtons[0].GetComponentInChildren<TextMeshProUGUI>().text = "True";
            optionButtons[1].GetComponentInChildren<TextMeshProUGUI>().text = "False";

            optionButtons[2].gameObject.SetActive(false);
            optionButtons[3].gameObject.SetActive(false);
        }
        else
        {
          
            for (int i = 0; i < optionButtons.Length; i++)
            {
                if (i < q.options.Length)
                {
                    
                    optionButtons[i].GetComponentInChildren<TextMeshProUGUI>().text = q.options[i];
                    optionButtons[i].gameObject.SetActive(true);
                }
                else
                {
                    
                    optionButtons[i].gameObject.SetActive(false);
                }
            }
        }
    }

    public void AnswerButton(int index)
    {

        Question q = currentQuestions[currentQuestionIndex];

        if ((!q.isTrueFalse && index == q.correctOptionIndex) ||
            (q.isTrueFalse && ((index == 0 && q.correctOptionIndex == 0) || (index == 1 && q.correctOptionIndex == 1))))
        {
            Debug.Log("Correct!");
            GameManager.Instance.AddScore(1);  
            Debug.Log("Current Score: " + GameManager.Instance.currentScore); 
        }
        else
        {
            Debug.Log("Try again!");
            Debug.Log("Current Score: " + GameManager.Instance.currentScore);
        }

      
        currentQuestionIndex++;
        DisplayQuestion();
    }
}
