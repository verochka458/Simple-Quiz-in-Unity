using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public List<Question> level1Questions;
    public List<Question> level2Questions;
    public List<Question> level3Questions;

    public int currentScore = 0;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); 
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void AddScore(int points)
    {
        currentScore += points;
    }

    public void LoadNextLevel(string levelName)
    {
        SceneManager.LoadScene(levelName);
    }

    public void RestartGame()
    {
        currentScore = 0;
        SceneManager.LoadScene("MainMenu");
    }

    public void FinishGame()
    {
        PlayerPrefs.SetInt("FinalScore", currentScore);
        SceneManager.LoadScene("GameOver"); 
    }

}
