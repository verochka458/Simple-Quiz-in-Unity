using UnityEngine;
using TMPro;

public class ResultManager : MonoBehaviour
{
    public TextMeshProUGUI scoreText;

    void Start()
    {
        int finalScore = PlayerPrefs.GetInt("FinalScore", 0);
        scoreText.text = "Your score: " + GameManager.Instance.currentScore.ToString();
    }

    public void RestartGame()
    {
        GameManager.Instance.RestartGame();
    }
}
