using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene("QuizLevel1");
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
